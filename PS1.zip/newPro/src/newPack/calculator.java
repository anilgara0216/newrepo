package newPack;

public class calculator {
	public void add(int a, int b) {
		System.out.println(a+b);
	}
	public static void main(String[] args) {
		calculator result = new calculator();
		result.add(2, 3);

	}

}
