package newPack;

public class Normal {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

	}

}
