package newPack;

public class ClassA {
	public static void main(String[] args) {
		int i;
		for(i=1; i<=6; i++)
		{
		System.out.println("JAI SHREE RAM");
		}
	}
}
